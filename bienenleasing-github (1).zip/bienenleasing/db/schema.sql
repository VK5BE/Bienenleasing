-- BienenLeasing – Schema-Entwurf (PostgreSQL + PostGIS)
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE user_role AS ENUM ('kunde','imker','admin');
CREATE TYPE contract_status AS ENUM ('requested','signed','active','ended','cancelled');
CREATE TYPE social_type AS ENUM ('youtube','facebook','web','instagram');

CREATE TABLE app_user (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role user_role NOT NULL,
  email text UNIQUE NOT NULL,
  validated_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE person_data (            -- gemeinsame Stammdaten für Imker & Kunde
  user_id uuid PRIMARY KEY REFERENCES app_user(id) ON DELETE CASCADE,
  nachname text NOT NULL,
  vorname text NOT NULL,
  anschrift text NOT NULL,
  telefon_1 text,
  telefon_2 text
);

CREATE TABLE social_link (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
  type social_type NOT NULL,
  url text NOT NULL
);  -- Kunde: nur facebook, web (Anwendungsregel)

CREATE TABLE offer (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  imker_id uuid NOT NULL REFERENCES app_user(id),
  colonies_available int NOT NULL CHECK (colonies_available >= 0),
  avg_yield_kg_year numeric(6,1),
  action_radius_km numeric(4,1),
  price_per_colony numeric(8,2),
  location_exact geography(Point,4326) NOT NULL,   -- nur für validierte Kunden
  location_public geography(Point,4326) NOT NULL,  -- gerastert / gefuzzt
  published boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX offer_geo_pub ON offer USING gist (location_public);

CREATE TABLE legal_document (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,                 -- agb | vertrags_agb | muster
  version text NOT NULL,
  valid_from date NOT NULL,
  content_url text NOT NULL,
  UNIQUE (type, version)
);

CREATE TABLE contract (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id uuid NOT NULL REFERENCES offer(id),
  kunde_id uuid NOT NULL REFERENCES app_user(id),
  colonies int NOT NULL CHECK (colonies > 0),
  term_start date NOT NULL,
  term_end date NOT NULL,
  legal_document_id uuid REFERENCES legal_document(id),
  status contract_status NOT NULL DEFAULT 'requested'
);

CREATE TABLE contract_event (          -- append-only, Hash-Kette
  id bigserial PRIMARY KEY,
  contract_id uuid NOT NULL REFERENCES contract(id),
  type text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}',
  prev_hash text,
  hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE payment (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES contract(id),
  amount numeric(10,2) NOT NULL,
  status text NOT NULL,
  provider_ref text
);

CREATE TABLE commission (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid UNIQUE NOT NULL REFERENCES contract(id),
  rate_model text NOT NULL,           -- fix | prozent | staffel
  amount numeric(10,2) NOT NULL
);

CREATE TABLE subscription (           -- Kundenverwaltung (kostenpflichtig)
  imker_id uuid PRIMARY KEY REFERENCES app_user(id),
  plan text NOT NULL,
  valid_until date NOT NULL
);

CREATE TABLE crm_contact (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  imker_id uuid NOT NULL REFERENCES app_user(id),
  kunde_id uuid NOT NULL REFERENCES app_user(id),
  notes text
);

CREATE TABLE content_item (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  body text,
  season text,                        -- fruehling | sommer | herbst | winter
  media_url text,
  published_at timestamptz
);
