---
name: Offene Frage
about: Klärungsbedarf aus dem Pflichtenheft
labels: question
---
**Frage**

**Optionen / Auswirkungen**

**Entscheidung durch**
