---
name: User Story
about: Anforderung als User Story erfassen
labels: story
---
**Als** <Rolle> **möchte ich** <Ziel>, **damit** <Nutzen>.

**Akzeptanzkriterien**
- [ ]

**Epic:** A–H (siehe docs/05-backlog.md)
