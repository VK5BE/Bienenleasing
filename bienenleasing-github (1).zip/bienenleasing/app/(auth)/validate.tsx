import { View, Text } from 'react-native';
import { colors, space } from '@/theme/tokens';

export default function Screen() {
  return (
    <View style={{ flex: 1, padding: space.lg, backgroundColor: colors.bg }}>
      <Text style={{ fontSize: 24, color: colors.ink }}>Validierung</Text>
      <Text style={{ color: colors.muted }}>S04 Kundendaten prüfen</Text>
    </View>
  );
}
