import { Tabs } from 'expo-router';
import { colors } from '@/theme/tokens';
export default function Layout() {
  return (<Tabs screenOptions={{ tabBarActiveTintColor: colors.primary }}>
    <Tabs.Screen name="uebersicht" options={{ title: 'Übersicht' }} />
    <Tabs.Screen name="angebote" options={{ title: 'Angebote' }} />
    <Tabs.Screen name="kunden" options={{ title: 'Kunden' }} />
    <Tabs.Screen name="profil" options={{ title: 'Profil' }} />
  </Tabs>);
}
