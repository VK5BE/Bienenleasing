import { View, Text } from 'react-native';
import { colors, space } from '@/theme/tokens';

export default function Screen() {
  return (
    <View style={{ flex: 1, padding: space.lg, backgroundColor: colors.bg }}>
      <Text style={{ fontSize: 24, color: colors.ink }}>Übersicht</Text>
      <Text style={{ color: colors.muted }}>S11 Völker, Anfragen, Saison</Text>
    </View>
  );
}
