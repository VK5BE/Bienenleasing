import { Tabs } from 'expo-router';
import { colors } from '@/theme/tokens';
export default function Layout() {
  return (<Tabs screenOptions={{ tabBarActiveTintColor: colors.primary }}>
    <Tabs.Screen name="suche" options={{ title: 'Suche' }} />
    <Tabs.Screen name="karte" options={{ title: 'Karte' }} />
    <Tabs.Screen name="vertraege" options={{ title: 'Mieten' }} />
    <Tabs.Screen name="profil" options={{ title: 'Profil' }} />
  </Tabs>);
}
