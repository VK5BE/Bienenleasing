import { View, Text } from 'react-native';
import { colors, space } from '@/theme/tokens';

export default function Screen() {
  return (
    <View style={{ flex: 1, padding: space.lg, backgroundColor: colors.bg }}>
      <Text style={{ fontSize: 24, color: colors.ink }}>In Ihrer Nähe</Text>
      <Text style={{ color: colors.muted }}>S05 Anonyme Umkreissuche ≤ 5 km</Text>
    </View>
  );
}
