// Design-Tokens – Richtung A „Lindenblüte“ (siehe docs/04-design-vorschlaege.md)
export const colors = {
  primary: '#1F4D36', accent: '#F2A81D', bg: '#F5F8F1',
  surface: '#E3EBD9', ink: '#17261D', muted: '#5E6F63', danger: '#C2452D', white: '#FFFFFF',
};
export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24 };
export const radius = { md: 12, lg: 16, pill: 999 };
export const font = { head: 'Fraunces', body: 'SourceSans3' };
