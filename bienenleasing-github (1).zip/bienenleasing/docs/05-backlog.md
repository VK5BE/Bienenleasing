# Backlog (Epics)

| Epic | Inhalt | MVP |
|---|---|---|
| A – Onboarding & Auth | Rollenwahl, Registrierung, Login, Validierung | ✅ |
| B – Imker-Angebote | Profil, Social Links, Angebot (Katalog), Veröffentlichung | ✅ |
| C – Suche & Karte | Anonyme Umkreissuche ≤ 5 km, Karte nach Validierung, Geo-Fuzzing | ✅ |
| D – Vertrag & Zahlung | Muster, AGB, Online-Abschluss, PDF-Versand, Audit-Log, Zahlung, Provision | ✅ |
| E – Kundenverwaltung | Premium-Abo, Kontakte, Notizen | ⏳ |
| F – Content & Community | Content-Upload, Saisonkalender, Winter-Themen, Community Services | ⏳ (Content-Basis im MVP) |
| G – Betrieb | 24/7-Monitoring, Wartungsfenster, Backups, EU-Hosting | ✅ |
| H – Backoffice | Provisionsregeln, AGB-Versionen, Validierung, Reporting | ✅ (minimal) |

## MVP-Reihenfolge
1. A → 2. B → 3. C → 4. D → 5. G/H → 6. F (Basis) → 7. E
