# Design-Vorschläge

Ziel: Vertrauen (Verträge, Zahlung, persönliche Daten) + Naturnähe + klare Kartenorientierung. Zielgruppe: Hobby-Imker (oft 50+) und naturinteressierte Kunden → große Touch-Flächen, hoher Kontrast, ruhige Oberfläche.

## Richtung A – „Lindenblüte“ (Empfehlung, im Mockup umgesetzt)
Freundlich, hell, vertrauenswürdig.
| Token | Hex |
|---|---|
| Lindenlaub (Primär) | `#1F4D36` |
| Honig (Akzent / CTA) | `#F2A81D` |
| Blütenweiß (Hintergrund) | `#F5F8F1` |
| Wachs (Flächen) | `#E3EBD9` |
| Tinte (Text) | `#17261D` |
| Mohn (Warnung) | `#C2452D` |

Typografie: Fraunces (Überschriften) + Source Sans 3 (Fließtext/UI). Eckenradius 16 px, Honig nur für die *eine* Hauptaktion je Screen.

## Richtung B – „Wabe“
Dunkel, hochwertig, Hexagon-Raster als Karten-/Icon-Motiv.
Hintergrund `#14110C` · Honigdunkel `#D98E04` · Wachsgelb `#F3D27A` · Rauch `#3A332A` · Kreide `#EDE6D6`.
Typografie: Sora + Inter. Risiko: Kontrast im Freien (Sonne), weniger „Hobby-nah“.

## Richtung C – „Feldkarte“
Karten-first, kühl und sachlich, topografische Anmutung.
Schiefer `#24414A` · Wiese `#8DB580` · Nebel `#E8EEF0` · Hagebutte `#D1495B` · Tinte `#0F1E24`.
Typografie: IBM Plex Sans. Stärke: Umkreissuche; Schwäche: weniger emotional.

## Gestaltungsprinzipien (alle Richtungen)
- Anonymisierte Darstellung = **Zonen/Kreise statt Pins**; Pins erst nach Validierung.
- **Keine Sterne/Bewertungen** – Vertrauen über Imker-Profil, Links und Katalogdaten.
- Winter-Modus: Startscreen zeigt Content (Einwinterung, Planung, Vorbestellung).
- Vertrag: Schritt-Anzeige, Zusammenfassung in einfacher Sprache, AGB-Link, klarer Abschluss-Button.
- Barrierefreiheit: min. 16 pt Text, 48 px Touch-Ziele, Kontrast ≥ 4,5:1.
