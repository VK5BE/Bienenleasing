# Anforderungen (aus dem Pflichtenheft abgeleitet)

## 1. Eckdaten
| Punkt | Wert aus Pflichtenheft |
|---|---|
| Plattformen | Android, iOS |
| Hobby-Imker in DE | 800.000 |
| Zielgruppe | 10 % (= 80.000 Imker) |
| Volumen je Imker | 20 Völker (= 10–20 Kunden) |
| Provision | einmalig (?) 9,90 € / Volk |
| Saison | Wintermonate sind thematisch nicht besetzt → Content/Community nötig |

## 2. Rollen
- **Plattformbetreiber** (App-Distributor & Content-Manager)
- **Imker** (Anbieter)
- **Kunde** (Mieter)

## 3. User Stories
### Plattformbetreiber
**Ökonomisch**
- Imker und Kunden zunächst **anonym** zusammenbringen.
- Anonymisierte Darstellung des Imkers mit grober Lokation („In Ihrer Nähe sind x Imker mit y Völkern verfügbar“), Umkreissuche ≤ 5 km.
- Nach Registrierung und Validierung der Kundendaten werden Lokationsdaten genauer freigegeben (Karte).
- Vertragsabschluss ermöglichen: Musterformular, Vertrags-AGB, Marketplace, Plattform-AGB.
- Flexible Provision auf abgeschlossene Verträge erhalten.
- Imkern eine Kundenverwaltung gegen Entgelt anbieten.

**Technisch**
- 24/7-Verfügbarkeit mit Wartungsfenstern.
- Einfache Content-Uploads.
- Registrierung für Imker und Kunden vor Vertragsabschluss verpflichtend.
- Vertragsabschluss **revisionssicher** tracken.
- Gängige Zahlungsfunktionen.

### Imker
- Bienenvölker vermieten; Anzahl und Standort verfügbarer Völker veröffentlichen.
- Vermietung = Leistungs- und Produktkatalog (zu definieren, z. B. Anzahl Völker, Ø-Ertrag/Jahr, Aktionsradius).

### Kunde
- Ein oder mehrere Völker über eine Laufzeit mieten.
- Imker aus der Umgebung auswählen, weiterführende Imker-Infos ansehen.
- Vertrag online verbindlich abschließen und später zugeschickt bekommen.

## 4. Datenfelder
| Imker | Kunde |
|---|---|
| Name, Vorname, Anschrift | Name, Vorname, Anschrift |
| Telefon 1, Telefon 2 | Telefon 1, Telefon 2 |
| Links: YouTube, Facebook, Webseite, Instagram | Links: Facebook, Webseite |

## 5. Ereignissteuerung (Event-Katalog)
`user.registered` · `user.validated` · `imker.profile_completed` · `offer.published` · `offer.updated` · `search.performed` · `contract.requested` · `contract.signed` · `contract.document_sent` · `payment.succeeded` · `payment.failed` · `commission.booked` · `crm.subscription_started` · `content.published`

## 6. Nicht-funktional
- Hosting/Server-Standort: **EU/Deutschland** (Entscheidung offen, DSGVO)
- Datenschutz & Security: Rollen-/Rechtekonzept, Verschlüsselung, Standort-Anonymisierung (Server-seitig!)
- Revisionssicherheit: Append-only-Ereignisprotokoll mit Hash-Kette
- Verfügbarkeit 24/7 mit Wartungsfenstern
- **Kein Bewertungssystem**

## 7. Offene Punkte / Unstimmigkeiten
1. **Volumen „1,6 Mio €“**: 80.000 × 20 Völker = 1,6 Mio *Völker*; × 9,90 € ≈ 15,8 Mio €. Bitte Einheit klären.
2. **Provision**: einmalig oder wiederkehrend je Laufzeit? „Flexibel“ → Modell (Fix/Prozent/Staffel) definieren.
3. **Katalog-Felder** der Vermietung („zu definieren“).
4. **Validierung** der Kundendaten: Methode (E-Mail+SMS, PostIdent, Adressprüfung)?
5. **Imker-Validierung**: Nachweis (Imkerverband, Veterinäramt-Registrierung)? Rechtlich prüfen.
6. **Zahlungsarten** und Auszahlung an Imker (Treuhand/Split-Payment?).
7. **Server-Standort** und Provider.
8. **Rechtliches**: Vertragsart (Miete/Pacht/Patenschaft), Steuer (Imker als Unternehmer?), Haftung – juristisch prüfen.
9. **Winter-Strategie**: Inhalte/Community-Services konkretisieren (siehe Backlog Epic F).
