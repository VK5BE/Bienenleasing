# App-Struktur

## 1. Rollen & Einstiege
```mermaid
flowchart TD
  W[Welcome / Rollenwahl] --> G[Gast: anonyme Umkreissuche]
  W --> R[Registrierung]
  R --> V[Validierung Kundendaten / Imkerprofil]
  V --> K[Kunden-Bereich]
  V --> I[Imker-Bereich]
  G -->|Registrieren| R
  K --> C[Vertrag abschließen]
  C --> P[Zahlung]
  I --> A[Angebot veröffentlichen]
  I --> CRM[Kundenverwaltung - kostenpflichtig]
```

## 2. Navigation
```
Welcome
├─ Gast
│  └─ Umkreissuche (anonym, ≤ 5 km)  →  Hinweis „Jetzt registrieren für genaue Standorte“
├─ Auth
│  ├─ Login
│  ├─ Registrierung (Rolle: Kunde | Imker)
│  └─ Validierung (Kundendaten / Imkerprofil)
├─ Kunde  (Tabs)
│  ├─ Suche        Liste + Filter (Umkreis, Anzahl Völker, Laufzeit)
│  ├─ Karte        genaue Standorte nach Validierung
│  ├─ Imker-Detail Katalog, Links (YouTube/FB/Web/Insta), Kontakt
│  ├─ Vertrag      Auswahl → Laufzeit → Vertragsprüfung → Zahlung → Bestätigung
│  ├─ Meine Mieten Verträge, Dokumente (PDF), Status
│  └─ Profil       Stammdaten (Tel 1/2, FB, Web), Datenschutz
├─ Imker  (Tabs)
│  ├─ Übersicht    Völker gesamt/vermietet/frei, Anfragen, Saison
│  ├─ Angebote     Liste + „Neues Angebot“ (Anzahl, Ø-Ertrag, Radius, Standort, Preis)
│  ├─ Kunden       Kundenverwaltung (Premium-Paywall)
│  └─ Profil       Stammdaten, Social Links, Abrechnung
├─ Community & Content (geteilt)
│  ├─ Saisonkalender (inkl. Winter-Themen)
│  ├─ Artikel / Videos
│  └─ Community Services (Foren, Termine – Ausbaustufe)
└─ Rechtliches: AGB, Vertrags-AGB, Datenschutz, Impressum
```

## 3. Screen-Liste
| ID | Screen | Rolle | Pfad |
|---|---|---|---|
| S01 | Welcome / Rollenwahl | alle | `app/index.tsx` |
| S02 | Login | alle | `app/(auth)/login.tsx` |
| S03 | Registrierung | alle | `app/(auth)/register.tsx` |
| S04 | Validierung | alle | `app/(auth)/validate.tsx` |
| S05 | Umkreissuche (anonym) | Gast/Kunde | `app/(kunde)/suche.tsx` |
| S06 | Karte | Kunde (validiert) | `app/(kunde)/karte.tsx` |
| S07 | Imker-Detail | Kunde | `app/(kunde)/imker/[id].tsx` |
| S08 | Vertragsabschluss | Kunde | `app/(kunde)/vertrag/[offerId].tsx` |
| S09 | Meine Mieten | Kunde | `app/(kunde)/vertraege.tsx` |
| S10 | Kunden-Profil | Kunde | `app/(kunde)/profil.tsx` |
| S11 | Imker-Übersicht | Imker | `app/(imker)/uebersicht.tsx` |
| S12 | Angebote | Imker | `app/(imker)/angebote.tsx` |
| S13 | Angebot erstellen | Imker | `app/(imker)/angebote/neu.tsx` |
| S14 | Kundenverwaltung | Imker | `app/(imker)/kunden.tsx` |
| S15 | Imker-Profil | Imker | `app/(imker)/profil.tsx` |
| S16 | Community/Content | alle | `app/(shared)/community.tsx` |
| S17 | Rechtliches | alle | `app/(shared)/legal.tsx` |

## 4. Plattformbetreiber-Backoffice (Web, nicht in der App)
Content-Management (Uploads), Provisionsregeln, AGB-/Vertragsvorlagen (versioniert), Vertrags-Audit, Nutzer-Validierung, Reporting.

## 5. Architekturvorschlag
| Schicht | Vorschlag |
|---|---|
| Mobile | Expo (React Native, TypeScript), Expo Router |
| Backend | NestJS (REST/OpenAPI) oder alternativ Django REST |
| DB | PostgreSQL + PostGIS (Umkreissuche, Geo-Fuzzing) |
| Events | Outbox-Pattern + Queue (z. B. BullMQ) für Ereignissteuerung |
| Zahlung | Stripe Connect / Mollie (Split-Payment, Provision) – prüfen |
| Verträge | PDF-Generierung aus versionierten Templates, Hash-Kette im Audit-Log |
| Hosting | EU/Deutschland (offen) |
| Content | Headless CMS (z. B. Strapi/Directus) fürs Backoffice |

**Wichtig:** Die Standort-Anonymisierung (Grobposition, Rasterung/Geo-Fuzzing) erfolgt **serverseitig**; exakte Koordinaten verlassen das Backend nur für validierte Kunden.
