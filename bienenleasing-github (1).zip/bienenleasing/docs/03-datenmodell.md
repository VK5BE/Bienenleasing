# Datenmodell (Entwurf)
```mermaid
erDiagram
  USER ||--o| IMKER_PROFILE : has
  USER ||--o| KUNDE_PROFILE : has
  USER ||--o{ SOCIAL_LINK : owns
  IMKER_PROFILE ||--o{ OFFER : publishes
  OFFER ||--o{ CONTRACT : "is booked in"
  KUNDE_PROFILE ||--o{ CONTRACT : signs
  CONTRACT ||--o{ CONTRACT_EVENT : "audit trail"
  CONTRACT ||--o{ PAYMENT : has
  CONTRACT ||--o| COMMISSION : yields
  IMKER_PROFILE ||--o{ CRM_CONTACT : manages
  IMKER_PROFILE ||--o| SUBSCRIPTION : books
  LEGAL_DOCUMENT ||--o{ CONTRACT : "version used"
  CONTENT_ITEM }o--|| USER : "authored by"
```

| Entität | Wichtige Felder |
|---|---|
| USER | id, role (kunde/imker/admin), email, validated_at |
| IMKER_PROFILE | nachname, vorname, anschrift, telefon_1, telefon_2 |
| KUNDE_PROFILE | nachname, vorname, anschrift, telefon_1, telefon_2 |
| SOCIAL_LINK | type (youtube/facebook/web/instagram), url |
| OFFER | colonies_available, avg_yield_kg_year, action_radius_km, price, location_exact, location_public |
| CONTRACT | offer_id, kunde_id, colonies, term_start/end, legal_doc_version, status |
| CONTRACT_EVENT | contract_id, type, payload, prev_hash, hash (append-only) |
| PAYMENT / COMMISSION | amount, status, provider_ref / rate_model, amount |
| CRM_CONTACT / SUBSCRIPTION | imker_id, kunde_id, notes / plan, valid_until |
| CONTENT_ITEM | title, body, season, media_url, published_at |
| LEGAL_DOCUMENT | type (agb/vertrags_agb/muster), version, valid_from |

Vollständiges SQL: [db/schema.sql](../db/schema.sql)
