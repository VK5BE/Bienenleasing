# BienenLeasing

Mobile App (Android & iOS) für das **Matchmaking zwischen Imkern und Kunden**, die ein oder mehrere Bienenvölker über eine Laufzeit mieten möchten.

> Stand: Entwurf v0.3 – abgeleitet aus *Leasing-App-Pflichtenheft 0.2*.

## Kernidee
1. Imker veröffentlichen Anzahl und Standort verfügbarer Völker (Leistungs- und Produktkatalog).
2. Kunden sehen zunächst **anonymisiert** „In Ihrer Nähe sind x Imker mit y Völkern verfügbar“ (Umkreis ≤ 5 km).
3. Nach **Registrierung + Validierung** werden Standorte genauer freigegeben (Karte).
4. Der Mietvertrag wird online verbindlich geschlossen, **revisionssicher protokolliert**, Zahlung über die Plattform.
5. Plattform erhält eine **flexible Provision** (Annahme: 9,90 € / Volk, einmalig – offen).
6. Imker können optional eine **Kundenverwaltung** (kostenpflichtig) buchen. **Kein Bewertungssystem.**

## Repository-Struktur
```
app/            Expo-Router-Screens (React Native + TypeScript)
src/theme/      Design-Tokens (Farben, Typografie, Abstände)
src/api/        API-Client (Platzhalter)
api/            OpenAPI-Spezifikation (Entwurf)
db/             PostgreSQL/PostGIS-Schema (Entwurf)
docs/           Anforderungen, App-Struktur, Datenmodell, Design, Backlog
.github/        Issue-Templates, CI
```

## Dokumentation
| Datei | Inhalt |
|---|---|
| [docs/01-anforderungen.md](docs/01-anforderungen.md) | User Stories, Ereignisse, NFR, offene Punkte |
| [docs/02-app-struktur.md](docs/02-app-struktur.md) | Rollen, Navigation, Screens, Architektur |
| [docs/03-datenmodell.md](docs/03-datenmodell.md) | ER-Diagramm & Entitäten |
| [docs/04-design-vorschlaege.md](docs/04-design-vorschlaege.md) | 3 Design-Richtungen, Empfehlung |
| [docs/05-backlog.md](docs/05-backlog.md) | Epics & MVP-Schnitt |

## Start (Frontend)
```bash
npm install
npx expo start
```
